#ifndef PERIOD_H
#define PERIOD_H
typedef struct Period
{
	char courseCode[100];
	char year[100];
	int perid;
	char group[100];
	char teacherName[100];
	int numStudents;
}period;
#endif