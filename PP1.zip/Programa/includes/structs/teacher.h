#ifndef TEACHER_H
#define TEACHER_H
typedef struct Teacher
{
	char name[100];
	int idCard;
}teacher;
#endif
