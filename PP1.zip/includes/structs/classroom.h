#ifndef CLASSROOM_H
#define CLASSROOM_H
typedef struct Classroom
{
	char name[100];
	int capacity;
} classroom;
#endif