#ifndef COURSE_H
#define COURSE_H
typedef struct Course
{
	char careerId[100];
	char courseId[100];
	char name[100];
} course;
#endif